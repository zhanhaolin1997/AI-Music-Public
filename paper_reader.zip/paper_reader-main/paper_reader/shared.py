from paper_reader.models.embedding import EmbeddingModel

em_model = EmbeddingModel("./bge-large-en-v1.5")